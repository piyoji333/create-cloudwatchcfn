import json
import yaml
import re

# グローバル変数でリソースを保持
resources = {}

def sanitize_resource_name(name):
    """
    リソース名から記号を除去し、アルファベットと数字のみを残す
    """
    return re.sub(r'[^a-zA-Z0-9]', '', name)

def get_opposite_comparison_operator(operator):
    """
    ComparisonOperator の反対条件を取得
    """
    opposites = {
        "GreaterThanThreshold": "LessThanOrEqualToThreshold",
        "LessThanThreshold": "GreaterThanOrEqualToThreshold",
        "GreaterThanOrEqualToThreshold": "LessThanThreshold",
        "LessThanOrEqualToThreshold": "GreaterThanThreshold",
    }
    return opposites.get(operator, operator)

def merge_resources(existing_resources, new_resource_name, new_resource_properties):
    """
    Resourcesセクションをマージする関数
    """
    existing_resources[new_resource_name] = {
        "Type": "AWS::CloudWatch::Alarm",
        "Properties": new_resource_properties,
    }
    return existing_resources

def generate_cloudformation_template(resources):
    """
    CloudFormationテンプレートを生成
    """
    template = {
        "AWSTemplateFormatVersion": "2010-09-09",
        "Resources": resources,
    }
    return yaml.dump(template, sort_keys=False)

def lambda_handler(event, context):
    try:
        # リクエストボディを読み込む
        body = json.loads(event.get('body', '{}'))

        # 必須フィールドを検証
        required_fields = ['metric_name', 'namespace', 'evaluation_periods', 'datapoints_to_alarm', 'threshold', 'period', 'comparison_operator', 'statistic', 'target']
        missing_fields = [field for field in required_fields if field not in body]
        if missing_fields:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": f"以下のフィールドが欠落しています: {', '.join(missing_fields)}"})
            }

        # リソース名を生成（記号を除去）
        raw_resource_name = f"{body['metric_name']}Alarm"
        resource_name = sanitize_resource_name(raw_resource_name)

        # CloudFormationのリソース部分を生成
        resource_properties = {
            "AlarmName": f"{body['metric_name']}-alarm",
            "MetricName": body["metric_name"],
            "Namespace": body["namespace"],
            "ComparisonOperator": body["comparison_operator"],
            "EvaluationPeriods": body["evaluation_periods"],
            "DatapointsToAlarm": body["datapoints_to_alarm"],
            "Threshold": body["threshold"],
            "Period": body["period"],
            "Statistic": body["statistic"],
            "AlarmActions": body.get("alarm_actions", []),
            "Dimensions": [
                {
                    "Name": "Target",
                    "Value": body["target"]
                }
            ]
        }

        # 既存のリソースに統合
        global resources
        resources = merge_resources(resources, resource_name, resource_properties)

        # 復旧用アラームを作成する場合
        if body.get('recovery_alarm'):
            recovery_resource_name = f"{resource_name}Recovery"
            recovery_comparison_operator = get_opposite_comparison_operator(body["comparison_operator"])
            recovery_resource_properties = {
                "AlarmName": f"{body['metric_name']}-recovery-alarm",
                "MetricName": body["metric_name"],
                "Namespace": body["namespace"],
                "ComparisonOperator": recovery_comparison_operator,  # 反対のComparisonOperatorを設定
                "EvaluationPeriods": body["evaluation_periods"],
                "DatapointsToAlarm": body["datapoints_to_alarm"],
                "Threshold": body["threshold"],  # アラーム条件時の閾値と同じ値
                "Period": body["period"],
                "Statistic": body["statistic"],
                "AlarmActions": body.get("alarm_actions", []),
                "Dimensions": [
                    {
                        "Name": "Target",
                        "Value": body["target"]
                    }
                ]
            }
            resources = merge_resources(resources, recovery_resource_name, recovery_resource_properties)

        # テンプレートを生成
        template_yaml = generate_cloudformation_template(resources)

        # レスポンスを返す
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({"template": template_yaml})
        }
    except json.JSONDecodeError:
        return {
            "statusCode": 400,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": "無効なJSON形式です"})
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": str(e)})
        }

